/**
 * 
 */
app.factory('FriendService',function($http){
	var friendService={}
	friendService.getAllSuggestedUsers=function(){
		return $http.get("http://localhost:8033/CollaborationMiddleware/suggestedusers")
	}
	friendService.addFriend=function(toId){
		console.log(toId)
		return $http.post("http://localhost:8033/CollaborationMiddleware/addfriend",toId)
	}
	
	return friendService;
})