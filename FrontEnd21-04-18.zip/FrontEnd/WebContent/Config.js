var app = angular.module('myApp', ['ngRoute','ngCookies']);

//configure our routes
app.config(function($routeProvider, $locationProvider) {
  $locationProvider.hashPrefix('');
	$routeProvider

		// route for the home page
		.when('/', {
			templateUrl : 'index.html'
        })
        
		.when('/addblog', {
			templateUrl : 'views/blogform.html',
			controller  : 'BlogController'
		})
		.when('/blogsnotapproved',{
		templateUrl:'views/blogsnotapproved.html',
			controller:'BlogController'
	})
	
	.when('/friends',{
		templateUrl:'views/friendsList.html',
		controller:'FriendCtrl'	
	})
	    .when('/adminBlog', {
		templateUrl : 'Blog/AdminBlog.html',
		controller  : 'AdminBlogController'
	})
	
	.when('/getblog/:id',{
		templateUrl:'views/blogdetails.html',
			controller:'BlogDetailsCtrl'
	})
	.when('/getblognotapproved/:id',{
		templateUrl:'views/blogapprovalform.html',
			controller:'BlogDetailsCtrl'
	})
	 .when('/adminForum', {
		templateUrl : 'Forum/adminForum.html',
		controller  : 'adminForumController'
	})
	 .when('/register', {
			templateUrl : 'views/register.html',
			controller  : 'UserController'
		})
		.when('/suggestedusers',{
		templateUrl:'views/suggestedusers.html',
		controller:'FriendCtrl'	
	})
	 .when('/login', {
				templateUrl : 'views/login.html',
				controller  : 'UserController'
			})
	.when('/UserHome', {
			templateUrl : 'Blog/Blog.html'
        })
        	
	 .when('/friend', {
				templateUrl : 'Friend/Friend.html',
				controller  : 'friendController'
			})
	.when('/job', {
			   templateUrl : 'Job/Job.html',
			   controller  : 'JobController'
		   })
	.when('/showjob', {
		   templateUrl : 'Job/showjob.html',
		   controller  : 'JobController'
	   })
    .when('/showfriend', {
		   templateUrl : 'Friend/ShowFriend.html',
		   controller  : 'FriendController'
	   })
    .when('/logout', {
			templateUrl : 'User/logout.html',
			controller  : 'userController'
		})
		
	.when('/chat', {
			templateUrl : 'Chat/Chat.html',
			controller  : 'ChatController'
		})
	.when('/profilepic', {
		templateUrl : 'User/Profilepic.html',

	})
	.when('/home', {
		templateUrl : 'home.html',

	})
	 .when('/friend', {
		   templateUrl : 'Friend/Friend.html',
		   controller  : 'FriendController'
	   });
	
	app.run(function($location,$rootScope,$cookiesStore){
		if($rootScope.loggedInUser==undefined)	
			$rootScope.loggedInUser==$cookiesStore.get('currentuser')
			console.log('config.js:'+$rootScope.loggedInUser.role)
			$rootScope.logout=function(){
			console.log('entering logout')
			UserService.logout().then(
					function(response){
				delete $rootScope.loggedInUser;
				$cookiesStore.remove('currentuser')
				$rootScope.message="Successfully loggedout.."
					$location.path('/login')
			},function(response){
				$rootScope.error=response.data
				if(response.status==401)
					$location.path('/login')
			})
		}
		})
			
});