/**
 * 
 */
app.controller('FriendCtrl',function($scope,$location,$rootScope,FriendService){
	function getAllSuggestedUsers(){
		console.log('Entering friend controller')
		FriendService.getAllSuggestedUsers().then(
				function(response){
				$scope.suggestedUsers=response.data
				console.log(response.data)
	},
	function(response){
		$rootScope.error=response.data
		if(response.status==401)
			$location.path('/login')
	})
	}
	$scope.addFriend=function(toId){
		console.log(toId)
		FriendService.addFriend(toId).then(
		function(response){
			alert('Friend request has been sent successfully...')
			getAllSuggestedUsers()
		},
		function(response){
			$rootScope.error=response.data
			if(response.status==401)
				$location.path('/login')
		})
	}
	
	
	getAllSuggestedUsers()
})	
