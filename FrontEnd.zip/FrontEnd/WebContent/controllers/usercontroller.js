/**
 * 
 */
app.controller('UserController', function($scope, $rootScope, $location, $cookieStore,
		UserService) {	
	$scope.registerUser = function(user) {
	console.log('entering usercontroller registerUser function in frontend'
				+ user)
		UserService.registerUser(user).then(function(response) {
			console.log('Registered Successfully... please login again..')
			$location.path('/home')
		}, function(response) {
			$scope.error = response.data
		})
	}
	$scope.login = function(user) {
		console.log('entering usercontroller login function in frontend'+user)		

		UserService.login(user).then(function(response) {
			$rootScope.loggedInUser = response.data
			console.log('userCTRL,loggedInUser:'+$rootScope.loggedInUser.role)
			$cookieStore.put('currentuser', response.data)
			$location.path('/addblog')
		})
	}
	
	})
