/**
 * BlogCtrl
 */
app.controller('BlogController',function($scope,$location,$rootScope,BlogService){
	$scope.addBlog=function(blog){
		console.log('BlogController, addblog:',blog)
		BlogService.addBlog(blog).then(
				function(response){
					alert('BlogPost is added successfully and it is waiting for approval');
					$location.path('/home')
				},
				function(response){
					$rootScope.error=response.data
					if(response.status==401)
						$location.path('/login')
				})
	}
	
	if($rootScope.loggedInUser.role=='ADMIN'){
		console.log('inside blogCTRL,blogsWaitingForApproval..');
		BlogService.getBlogsWaitingForApproval()
		.then(
				function(response){
					console.log('blogCTRL,blogsWaitingForApproval:',response.data);
					$scope.blogsWaitingForApproval=response.data
				},function(response){
					$rootScope.error=response.data
					if(response.status==401)
						$location.path('/login')
				})
		}
	
	
	})