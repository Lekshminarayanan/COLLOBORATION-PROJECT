/**
 * BlogService
 */
app.factory('BlogService',function($http){
	var blogService={}
blogService.addBlog=function(blog)
{       
		console.log('BlogService,addblog:',blog)
		return $http.post("http://localhost:8033/CollaborationMiddleware/addblogpost",blog)
}

	blogService.getBlogsWaitingForApproval=function(){
		console.log('BlogService,getblogswaitingforapproval..')
		return $http.get("http://localhost:8033/CollaborationMiddleware/getBlogsWaitingForApproval/"+0)
	}
	blogService.getBlogApproved=function(){
		return $http.get("http://localhost:8033/CollaborationMiddleware/getblogs/"+1)
	}

	blogService.getBlog=function(id){
		return $http.get("http://localhost:8033/CollaborationMiddleware/getblog/"+id)
	}
	blogService.approve=function(blog){
		return $http.put("http://localhost:8033/CollaborationMiddleware/approve/"+blog)
	}
	blogService.reject=function(blog,rejectionReason){
		return $http.put("http://localhost:8033/CollaborationMiddleware/reject/"+rejectionReason, blog)
	}
return blogService;
})